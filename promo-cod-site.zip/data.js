const promokodlar = [
  {
    ilova: "Yandex Market",
    davlat: "O‘zbekiston",
    shart: "Birinchi buyurtma uchun",
    chegirma: "21000",
    kod: "SAVDO",
    muddat: "2025-04-30"
  },
  {
    ilova: "Uzum Tezkor",
    davlat: "O‘zbekiston",
    shart: "Birinchi 3 ta buyurtma uchun",
    chegirma: "30000",
    kod: "324K6",
    muddat: "2025-04-30"
  },
  {
    ilova: "Express24",
    davlat: "O‘zbekiston",
    shart: "Birinchi buyurtma uchun",
    chegirma: "15000",
    kod: "UKABK",
    muddat: "2025-04-30"
  }
];
